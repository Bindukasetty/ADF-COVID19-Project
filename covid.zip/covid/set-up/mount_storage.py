# Databricks notebook source
# MAGIC %md
# MAGIC ## Mount the following data lake storage gen2 containers
# MAGIC 1. raw
# MAGIC 2. processed
# MAGIC 3. lookup

# COMMAND ----------

# MAGIC %md
# MAGIC ### Set-up the configs
# MAGIC #### Please update the following 
# MAGIC - application-id
# MAGIC - service-credential
# MAGIC - directory-id

# COMMAND ----------

configs = {"fs.azure.account.auth.type": "OAuth",
           "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
           "fs.azure.account.oauth2.client.id": "c1e34538-abc5-4778-822e-3dde85261379",
           "fs.azure.account.oauth2.client.secret": "ELw8Q~9ODxZ-TEv2FCXeHJYGHotBHazNZ4uNgc1l",
           "fs.azure.account.oauth2.client.endpoint": "https://login.microsoftonline.com/bbe6fa90-47c8-47a1-8ea5-e67d87b594a7/oauth2/token"}

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mount the raw container
# MAGIC #### Update the storage account name before executing

# COMMAND ----------

# DBTITLE 1,Cell 5
for k, v in configs.items():
  spark.conf.set(k, v)

raw_path = "abfss://raw@covidadfprojectdl.dfs.core.windows.net/"
display(dbutils.fs.ls(raw_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mount the processed container
# MAGIC #### Update the storage account name before executing

# COMMAND ----------

for k, v in configs.items():
  spark.conf.set(k, v)

processed_path = "abfss://processed@covidadfprojectdl.dfs.core.windows.net/"
display(dbutils.fs.ls(processed_path))

# COMMAND ----------

# MAGIC %md
# MAGIC ### Mount the lookup container
# MAGIC #### Update the storage account name before executing

# COMMAND ----------

for k, v in configs.items():
  spark.conf.set(k, v)

lookup_path = "abfss://lookup@covidadfprojectdl.dfs.core.windows.net/"
display(dbutils.fs.ls(lookup_path))